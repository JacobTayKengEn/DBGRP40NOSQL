import pandas as pd
from pymongo import MongoClient
import os

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client["your_database_name"]  # Replace 'your_database_name' with your MongoDB database name

# Function to remove duplicates based on a specified field
def remove_duplicates(collection, unique_field):
    pipeline = [
        {"$group": {"_id": f"${unique_field}", "count": {"$sum": 1}, "ids": {"$push": "$_id"}}},
        {"$match": {"count": {"$gt": 1}}}
    ]
    duplicates = list(collection.aggregate(pipeline))

    for duplicate in duplicates:
        ids_to_delete = duplicate["ids"][1:]  # Keep the first entry, delete others
        collection.delete_many({"_id": {"$in": ids_to_delete}})
    print(f"Removed duplicates from collection '{collection.name}' based on field '{unique_field}'.")

# Define CSV files with paths in the 'studentVle' folder
csv_files = {
    "courses": "studentVle/courses.csv",
    "studentInfo": "studentVle/studentInfo.csv",
    "studentRegistration": "studentVle/studentRegistration.csv",
    "assessments": "studentVle/assessments.csv",
    "studentAssessment": "studentVle/studentAssessment.csv",
}

# Load CSV files into MongoDB
def load_csv_to_mongo(collection_name, csv_file_path):
    df = pd.read_csv(csv_file_path)

    if collection_name == "studentAssessment" and 'score' in df.columns:
        df = df[df['score'].notna()]  # Filter rows with NaN scores

    data = df.to_dict(orient="records")
    db[collection_name].insert_many(data)
    print(f"Data loaded into '{collection_name}' collection successfully with NaN scores removed.")

# Create Indexes for Faster Query Performance
def create_indexes():
    db["studentInfo"].create_index("id_student", unique=True)
    db["studentInfo"].create_index([("code_module", 1), ("code_presentation", 1)])
    db["courses"].create_index([("code_module", 1), ("code_presentation", 1)], unique=True)
    db["studentRegistration"].create_index("id_student")
    db["studentRegistration"].create_index([("code_module", 1), ("code_presentation", 1)])
    db["assessments"].create_index("id_assessment", unique=True)
    db["assessments"].create_index([("code_module", 1), ("code_presentation", 1)])
    db["studentAssessment"].create_index("id_assessment")
    db["studentAssessment"].create_index("id_student")
    print("Indexes created successfully.")

# Main execution
def main():
    user_input = input("Do you want to upload CSV files to the database? (yes/no): ").strip().lower()
    if user_input == "yes":
        for collection, file_path in csv_files.items():
            if os.path.exists(file_path):
                load_csv_to_mongo(collection, file_path)
            else:
                print(f"File not found: {file_path}")
    
    # Remove duplicates
    remove_duplicates(db["studentInfo"], "id_student")
    remove_duplicates(db["courses"], ["code_module", "code_presentation"])
    remove_duplicates(db["assessments"], "id_assessment")

    # Create indexes
    create_indexes()

if __name__ == "__main__":
    main()

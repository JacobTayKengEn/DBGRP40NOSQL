from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError, OperationFailure
from datetime import datetime, timedelta
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, silhouette_score
import matplotlib.pyplot as plt
from dotenv import load_dotenv
import os
import streamlit as st
from sklearn.preprocessing import MinMaxScaler


# Session timeout configuration
SESSION_TIMEOUT_MINUTES = 15
# Load environment variables from the .env file
load_dotenv()

# MongoDB URI template loaded from the environment
MONGO_URI_TEMPLATE = os.getenv("MONGO_URI_TEMPLATE")

# Function to set up a MongoDB client dynamically with a specific username and password
def get_mongo_client(username, password):
    if not MONGO_URI_TEMPLATE:
        raise ValueError("MongoDB URI template is not defined in the .env file.")

    # Replace placeholders with provided username and password
    uri = MONGO_URI_TEMPLATE.format(username=username, password=password)
    client = MongoClient(uri)
    db = client["StudentVLE"]
    return db

# Function to validate student data
def validate_student_data(data, require_id=True):
    errors = []

    # Validate Student ID only if required (e.g., for insert but not for update)
    if require_id and (not isinstance(data.get("id_student"), int) or data["id_student"] <= 0):
        errors.append("Student ID must be a positive integer.")

    # Studied credits should be a positive integer
    if not isinstance(data.get("studied_credits"), int) or data["studied_credits"] <= 0:
        errors.append("Studied credits must be a positive integer.")

    # Number of previous attempts should be non-negative
    if not isinstance(data.get("num_of_prev_attempts"), int) or data["num_of_prev_attempts"] < 0:
        errors.append("Number of previous attempts must be a non-negative integer.")

    # Ensure required fields are not empty
    required_fields = ["code_module", "code_presentation", "gender", "imd_band", "highest_education", "age_band", "region", "disability", "final_result"]
    for field in required_fields:
        if not data.get(field):
            errors.append(f"{field} is required and cannot be empty.")

    return errors


# Check for duplicate student entry
def check_duplicate_student(db, student_id):
    student_info = db["studentInfo"]
    return student_info.find_one({"id_student": student_id}) is not None

# Insert Student with validation and duplication check
# Insert Student with validation and duplication check
def insert_student(db, data):
    print("Insert Student called with data:", data)  # Debugging

    # Check for duplicate
    if check_duplicate_student(db, data.get("id_student")):
        print(f"Duplicate detected for ID: {data['id_student']}")
        return f"Student with ID {data['id_student']} already exists."

    # Validate data
    errors = validate_student_data(data, require_id=True)
    if errors:
        print("Validation errors:", errors)  # Debugging
        return "Failed to insert student. Errors: " + "; ".join(errors)

    try:
        # Insert into database
        student_info = db["studentInfo"]
        result = student_info.insert_one(data)
        print("Insert result:", result.inserted_id)  # Debugging
        return f"Student inserted successfully! ID: {result.inserted_id}"
    except DuplicateKeyError:
        print("DuplicateKeyError encountered")  # Debugging
        return "Student with this ID already exists."
    except Exception as e:
        print("Unexpected error:", e)  # Debugging
        return f"An unexpected error occurred: {e}"


# Find Student by ID
def find_student_by_id(db, student_id):
    student_info = db["studentInfo"]
    student = student_info.find_one({"id_student": student_id})
    if student:
        student["_id"] = str(student["_id"])
    return student


# Update Student with validation
def update_student(db, student_id, update_data, user_id):
    errors = validate_student_data(update_data, require_id=False)
    if errors:
        return "Failed to update student. Errors: " + "; ".join(errors)

    try:
        student_info = db["studentInfo"]
        result = student_info.update_one(
            {"id_student": student_id, "lock": user_id},
            {"$set": update_data}
        )
        return "Student updated successfully!" if result.modified_count > 0 else "Failed to update student. Lock might have been released."
    except OperationFailure as e:
        return f"Database operation failed: {e}"
    except Exception as e:
        return f"An unexpected error occurred: {e}"

# Delete Student by ID with error handling
def delete_student(db, student_id):
    try:
        student_info = db["studentInfo"]
        result = student_info.delete_one({"id_student": student_id})
        return "Student deleted successfully!" if result.deleted_count > 0 else "Student not found."
    except Exception as e:
        return f"An unexpected error occurred: {e}"

# Lock and Unlock Mechanism with Timeout
def lock_student_record(db, student_id, user_id, timeout_minutes=10):
    student_info = db["studentInfo"]
    lock_time = datetime.utcnow() + timedelta(minutes=timeout_minutes)
    result = student_info.update_one(
        {"id_student": student_id, "lock": {"$exists": False}},
        {"$set": {"lock": user_id, "lock_timeout": lock_time}}
    )
    return result.modified_count > 0

def unlock_student_record(db, student_id):
    student_info = db["studentInfo"]
    result = student_info.update_one(
        {"id_student": student_id},
        {"$unset": {"lock": "", "lock_timeout": ""}}
    )
    return result.modified_count > 0

def release_expired_locks(db):
    current_user = st.session_state.get("username", None)
    
    # Only allow the update if the user has appropriate permissions
    if current_user and "Update Student" in st.session_state["permissions"]:
        student_info = db["studentInfo"]
        current_time = datetime.utcnow()
        result = student_info.update_many(
            {"lock_timeout": {"$lt": current_time}},
            {"$unset": {"lock": "", "lock_timeout": ""}}
        )
        return result.modified_count
    else:
        # If user doesn't have update permissions, do not perform update
        return "User does not have permission to perform update operations."


# Identify At-Risk Students
def identify_at_risk_students(db):
    student_info = db["studentInfo"]
    student_registration = db["studentRegistration"]
    at_risk_students = list(student_info.aggregate([
        {
            "$match": {
                "num_of_prev_attempts": {"$gte": 1},
                "final_result": {"$ne": "Pass"}
            }
        },
        {
            "$lookup": {
                "from": "studentRegistration",
                "localField": "id_student",
                "foreignField": "id_student",
                "as": "registration_info"
            }
        },
        {"$unwind": "$registration_info"},
        {
            "$match": {
                "registration_info.date_registration": {"$gt": 0},
                "registration_info.date_unregistration": {"$exists": True}
            }
        }
    ]))
    return at_risk_students

# Module Difficulty Comparison
def compare_presentation_difficulty(db):
    student_assessment = db["studentAssessment"]
    difficulty_scores = list(student_assessment.aggregate([
        {
            "$lookup": {
                "from": "assessments",
                "localField": "id_assessment",
                "foreignField": "id_assessment",
                "as": "assessment_info"
            }
        },
        {"$unwind": "$assessment_info"},
        {"$match": {"score": {"$exists": True, "$ne": None}}},
        {
            "$group": {
                "_id": {
                    "module": "$assessment_info.code_module",
                    "presentation": "$assessment_info.code_presentation"
                },
                "average_score": {"$avg": "$score"},
                "assessment_count": {"$sum": 1}
            }
        },
        {"$sort": {"_id.module": 1, "_id.presentation": 1}}
    ]))
    return difficulty_scores

# Student Performance Clustering with dynamic k and interpretation
def student_performance_clustering(db):
    student_assessment = db["studentAssessment"]
    assessments = db["assessments"]

    # Aggregate data
    student_data = list(student_assessment.aggregate([
        {
            "$lookup": {
                "from": "assessments",
                "localField": "id_assessment",
                "foreignField": "id_assessment",
                "as": "assessment_info"
            }
        },
        {"$unwind": "$assessment_info"},
        {"$match": {"score": {"$exists": True, "$ne": None}}},
        {
            "$group": {
                "_id": {"student": "$id_student", "module": "$assessment_info.code_module"},
                "average_score": {"$avg": "$score"},
                "assessment_count": {"$sum": 1}
            }
        }
    ]))

    # Convert to DataFrame
    df = pd.DataFrame(student_data)
    if df.empty:
        return []

    # Prepare data for clustering
    X = df[['average_score', 'assessment_count']]
    kmeans = KMeans(n_clusters=3, random_state=42)
    df['cluster'] = kmeans.fit_predict(X)

    # Dynamically determine cluster names
    cluster_means = df.groupby('cluster')[['average_score', 'assessment_count']].mean()
    sorted_clusters = cluster_means.sort_values(by='average_score').index.tolist()

    # Map cluster labels to names
    cluster_mapping = {
        sorted_clusters[0]: "Low Performers",
        sorted_clusters[1]: "Moderate Performers",
        sorted_clusters[2]: "High Performers"
    }
    df['cluster_name'] = df['cluster'].map(cluster_mapping)

    # Prepare clustering results
    clustering_results = []
    for cluster_id, cluster_name in cluster_mapping.items():
        cluster_data = df[df['cluster'] == cluster_id]
        avg_score = cluster_data['average_score'].mean()
        avg_count = cluster_data['assessment_count'].mean()

        characteristics = ""
        if cluster_name == "High Performers":
            characteristics = "Consistently high scores, likely engaged and successful students."
        elif cluster_name == "Moderate Performers":
            characteristics = "Average scores, indicating steady but moderate performance."
        elif cluster_name == "Low Performers":
            characteristics = "Lower scores and fewer assessments, potentially at risk of struggling."

        clustering_results.append({
            "cluster": cluster_name,
            "total_students": len(cluster_data),
            "average_score": avg_score,
            "average_assessment_count": avg_count,
            "characteristics": characteristics
        })

    return clustering_results


# Module Success Prediction with error handling
def predict_module_success(db):
    student_info = db["studentInfo"]
    student_data = list(student_info.aggregate([
        {"$match": {"final_result": {"$exists": True}}},
        {
            "$project": {
                "id_student": 1,
                "region": 1,
                "highest_education": 1,
                "imd_band": 1,
                "age_band": 1,
                "num_of_prev_attempts": 1,
                "studied_credits": 1,
                "disability": 1,
                "final_result": {"$cond": {"if": {"$eq": ["$final_result", "Pass"]}, "then": 1, "else": 0}}
            }
        }
    ]))

    df = pd.DataFrame(student_data)
    if df.empty:
        return None, None

    X = pd.get_dummies(df[['region', 'highest_education', 'imd_band', 'age_band', 'num_of_prev_attempts', 'studied_credits', 'disability']])
    y = df['final_result']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    feature_importances = pd.DataFrame({
        'feature': X.columns,
        'importance': model.feature_importances_
    }).sort_values(by='importance', ascending=False)

    return accuracy, feature_importances

# Helper functions for unique options
def get_unique_modules(db):
    student_info = db["studentInfo"]
    return sorted(student_info.distinct("code_module"))

def get_unique_presentations(db):
    student_info = db["studentInfo"]
    return sorted(student_info.distinct("code_presentation"))

def get_unique_imd_bands(db):
    student_info = db["studentInfo"]
    return sorted([str(band) for band in student_info.distinct("imd_band")])

def get_unique_highest_education(db):
    student_info = db["studentInfo"]
    return sorted(student_info.distinct("highest_education"))

def get_unique_regions(db):
    student_info = db["studentInfo"]
    return sorted(student_info.distinct("region"))

# Add this at the end to indicate successful edits
if __name__ == "__main__":
    print("Functions file successfully updated with dynamic MongoDB URI handling.")

import streamlit as st
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import pandas as pd
from functions import (
    get_mongo_client, insert_student, find_student_by_id, update_student, delete_student,
    identify_at_risk_students, compare_presentation_difficulty,
    student_performance_clustering, predict_module_success,
    get_unique_modules, get_unique_presentations,
    get_unique_imd_bands, get_unique_highest_education,
    get_unique_regions, lock_student_record, unlock_student_record,
    release_expired_locks
)

# Session timeout configuration
SESSION_TIMEOUT_MINUTES = 15

def initialize_session():
    """Initialize session variables on the first load."""
    if "authenticated" not in st.session_state:
        st.session_state["authenticated"] = False
    if "username" not in st.session_state:
        st.session_state["username"] = None
    if "permissions" not in st.session_state:
        st.session_state["permissions"] = []
    if "db" not in st.session_state:
        st.session_state["db"] = None
    if "last_activity" not in st.session_state:
        st.session_state["last_activity"] = datetime.utcnow()

def is_session_expired():
    """Check if the session is expired based on inactivity."""
    if st.session_state["authenticated"]:
        current_time = datetime.utcnow()
        last_activity = st.session_state["last_activity"]
        return (current_time - last_activity) > timedelta(minutes=SESSION_TIMEOUT_MINUTES)
    return False

def update_last_activity():
    """Update last activity timestamp."""
    st.session_state["last_activity"] = datetime.utcnow()

# Initialize session on app load
initialize_session()

# Check session timeout
if is_session_expired():
    st.session_state["authenticated"] = False
    st.session_state["username"] = None
    st.session_state["permissions"] = []
    st.session_state["db"] = None
    st.warning("Session expired due to inactivity. Please log in again.")
else:
    update_last_activity()

# MongoDB Authentication
def authenticate(username, password):
    try:
        db = get_mongo_client(username, password)
        db.command("ping")  # Test if user has access
        roles = db.command("usersInfo", username)["users"][0]["roles"]
        permissions = []
        for role in roles:
            if role['role'] in ['atlasAdmin', 'readWriteAnyDatabase']:
                permissions = [
                    "Insert Student", "Find Student", "Update Student", "Delete Student",
                    "Identify At-Risk Students", "Module Difficulty Comparison",
                    "Student Performance Clustering", "Module Success Prediction"
                ]
            elif role['role'] == 'readAnyDatabase':
                permissions = [
                    "Find Student", "Identify At-Risk Students", "Module Difficulty Comparison",
                    "Student Performance Clustering", "Module Success Prediction"
                ]
        return True, db, permissions
    except Exception as e:
        print("Authentication failed:", e)
        return False, None, []

# Login Page
if not st.session_state["authenticated"]:
    st.title("Login to Student Management System")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        authenticated, db, permissions = authenticate(username, password)
        if authenticated:
            st.session_state["authenticated"] = True
            st.session_state["username"] = username
            st.session_state["permissions"] = permissions
            st.session_state["db"] = db
            st.success("Login successful!")
            st.experimental_set_query_params(logged_in="true")
        else:
            st.error("Invalid username or password.")
else:
    db = st.session_state["db"]
    st.title("Student Management System")
    st.sidebar.write(f"Logged in as: {st.session_state['username']}")

    # Run lock expiration cleanup on each load
    release_expired_locks(db)

    menu = st.session_state["permissions"]
    choice = st.sidebar.selectbox("Select Option", menu)

    if choice == "Insert Student":
        st.subheader("Insert New Student")
        module_options = get_unique_modules(db)
        presentation_options = get_unique_presentations(db)
        imd_band_options = get_unique_imd_bands(db)
        highest_education_options = get_unique_highest_education(db)
        region_options = get_unique_regions(db)

        code_module = st.selectbox("Module", module_options)
        code_presentation = st.selectbox("Presentation", presentation_options)
        id_student = st.number_input("Student ID", step=1)
        gender = st.selectbox("Gender", ["M", "F", "Other"])
        imd_band = st.selectbox("IMD Band", imd_band_options)
        highest_education = st.selectbox("Highest Education", highest_education_options)
        age_band = st.selectbox("Age Band", ["0-35", "35-55", "55<= "])
        num_of_prev_attempts = st.number_input("Previous Attempts", step=1)
        studied_credits = st.number_input("Studied Credits", step=1)
        region = st.selectbox("Region", region_options)
        disability = st.selectbox("Disability", ["Y", "N"])
        final_result = st.selectbox("Final Result", ["Distinction", "Pass", "Fail", "Withdrawn"])

        if st.button("Insert Student"):
            student_data = {
                "code_module": code_module,
                "code_presentation": code_presentation,
                "id_student": int(id_student),
                "gender": gender,
                "imd_band": imd_band,
                "highest_education": highest_education,
                "age_band": age_band,
                "num_of_prev_attempts": int(num_of_prev_attempts),
                "studied_credits": int(studied_credits),
                "region": region,
                "disability": disability,
                "final_result": final_result
            }
            message = insert_student(db, student_data)
            st.success(message)

    elif choice == "Find Student":
        st.subheader("Find Student by ID")
        student_id = st.number_input("Enter Student ID", step=1)

        if st.button("Find Student"):
            student_record = find_student_by_id(db, int(student_id))
            if student_record:
                st.write("Student found:", student_record)
            else:
                st.error("Student not found.")

    elif choice == "Update Student":
        st.subheader("Update Student Information")
        student_id = st.number_input("Enter Student ID to update", step=1)

        if st.button("Find Student for Update"):
            student_record = find_student_by_id(db, int(student_id))
            if student_record:
                lock_owner = student_record.get("lock")
                st.write("Current lock status:", lock_owner)  # Debugging statement

                if lock_owner:
                    st.warning(f"This record is currently being edited by another user: {lock_owner}")
                else:
                    current_user = st.session_state["username"]
                    if lock_student_record(db, student_id, current_user):
                        st.session_state["student_record"] = student_record
                        st.session_state["lock_user"] = current_user
                        st.success("Student found and locked for editing.")
                    else:
                        st.error("Failed to lock the record. It might already be locked.")
            else:
                st.error("Student not found.")

        if "student_record" in st.session_state and st.session_state["student_record"] is not None:
            student_record = st.session_state["student_record"]
            module_options = get_unique_modules(db)
            presentation_options = get_unique_presentations(db)
            imd_band_options = get_unique_imd_bands(db)
            highest_education_options = get_unique_highest_education(db)
            region_options = get_unique_regions(db)

            code_module = st.selectbox("Module", module_options, index=module_options.index(student_record["code_module"]))
            code_presentation = st.selectbox("Presentation", presentation_options, index=presentation_options.index(student_record["code_presentation"]))
            gender = st.selectbox("Gender", ["M", "F", "Other"], index=["M", "F", "Other"].index(student_record["gender"]))
            imd_band = st.selectbox("IMD Band", imd_band_options, index=imd_band_options.index(student_record["imd_band"]))
            highest_education = st.selectbox("Highest Education", highest_education_options, index=highest_education_options.index(student_record["highest_education"]))
            age_band = st.selectbox("Age Band", ["0-35", "35-55", "55<= "], index=["0-35", "35-55", "55<= "].index(student_record["age_band"]))
            num_of_prev_attempts = st.number_input("Previous Attempts", value=student_record["num_of_prev_attempts"], step=1)
            studied_credits = st.number_input("Studied Credits", value=student_record["studied_credits"], step=1)
            region = st.selectbox("Region", region_options, index=region_options.index(student_record["region"]))
            disability = st.selectbox("Disability", ["Y", "N"], index=["Y", "N"].index(student_record["disability"]))
            final_result = st.selectbox("Final Result", ["Distinction", "Pass", "Fail", "Withdrawn"], index=["Distinction", "Pass", "Fail", "Withdrawn"].index(student_record["final_result"]))

            if st.button("Update Student"):
                update_data = {
                    "code_module": code_module,
                    "code_presentation": code_presentation,
                    "gender": gender,
                    "imd_band": imd_band,
                    "highest_education": highest_education,
                    "age_band": age_band,
                    "num_of_prev_attempts": int(num_of_prev_attempts),
                    "studied_credits": int(studied_credits),
                    "region": region,
                    "disability": disability,
                    "final_result": final_result,
                    "lock": None  # Clear the lock after updating
                }
                try:
                    message = update_student(db, int(student_id), update_data, st.session_state["lock_user"])
                    st.success(message)
                except Exception as e:
                    st.error(f"Error updating student: {e}")
                finally:
                    unlock_student_record(db, student_id)
                    st.session_state["student_record"] = None

            if st.button("Cancel Update"):
                unlock_student_record(db, student_id)
                st.warning("Update canceled, and lock released.")
                st.session_state["student_record"] = None

    elif choice == "Delete Student":
        st.subheader("Delete Student by ID")
        student_id = st.number_input("Enter Student ID to delete", step=1)

        if st.button("Delete Student"):
            result = delete_student(db, int(student_id))
            st.success(result)

    elif choice == "Identify At-Risk Students":
        st.subheader("At-Risk Students")
        at_risk_students = identify_at_risk_students(db)
        if at_risk_students:
            for student in at_risk_students:
                st.write(f"Student ID: {student['id_student']}")
                st.write(f" - Module: {student['code_module']}")
                st.write(f" - Presentation: {student['code_presentation']}")
                st.write(f" - Prior Attempts: {student['num_of_prev_attempts']}")
                st.write(f" - Registration Date: {student['registration_info']['date_registration']}")
                st.write(f" - Unregistered Date: {student['registration_info'].get('date_unregistration', 'N/A')}")
        else:
            st.write("No at-risk students found.")

    elif choice == "Module Difficulty Comparison":
        st.subheader("Module Difficulty Comparison")
        difficulty_scores = compare_presentation_difficulty(db)
        if isinstance(difficulty_scores, list) and difficulty_scores:
            for result in difficulty_scores:
                st.write(f"Module: {result['_id']['module']}")
                st.write(f" - Presentation: {result['_id']['presentation']}")
                st.write(f" - Average Score: {result['average_score']:.2f}")
                st.write(f" - Number of Assessments: {result['assessment_count']}")
        else:
            st.write("No data available for module difficulty comparison.")

    # Student Performance Clustering
    elif choice == "Student Performance Clustering":
        st.subheader("Student Performance Clustering")
        clustering_data = student_performance_clustering(db)

        if clustering_data:
            for cluster in clustering_data:
                st.markdown(f"### Cluster: {cluster['cluster']}")
                st.markdown("- **Total Students:** {}".format(cluster['total_students']))
                st.markdown("- **Average Score:** {:.2f}".format(cluster['average_score']))
                st.markdown("- **Average Assessment Count:** {:.2f}".format(cluster['average_assessment_count']))
                st.markdown(f"- **Characteristics:** {cluster['characteristics']}")
                st.markdown("---")
        else:
            st.write("No data available for clustering.")



    elif choice == "Module Success Prediction":
        st.subheader("Module Success Prediction")
        accuracy, feature_importances = predict_module_success(db)
        if accuracy is not None and feature_importances is not None:
            st.write(f"Module success prediction accuracy: {accuracy * 100:.2f}%")
            st.write("Top Contributing Features to Student Success/Failure:")
            st.dataframe(feature_importances.head(10))
            st.subheader("Feature Importance for Module Success Prediction")
            plt.figure(figsize=(10, 6))
            plt.bar(feature_importances['feature'], feature_importances['importance'])
            plt.xticks(rotation=90)
            plt.xlabel('Feature')
            plt.ylabel('Importance')
            plt.title('Feature Importance for Module Success Prediction')
            st.pyplot(plt)
            top_features = feature_importances['feature'].head(3).values
            st.subheader("Interpretation:")
            st.write(f"The most influential factor in predicting module success is '{top_features[0]}'.")
            st.write(f"High values in features like '{', '.join(top_features)}' may indicate barriers to success.")
            st.write("Supporting students based on these features can potentially improve overall success rates.")
        else:
            st.write("No data available for module success prediction.")

    if st.sidebar.button("Logout"):
        st.session_state["authenticated"] = False
        st.session_state["username"] = None
        st.session_state["permissions"] = []
        st.session_state["db"] = None
        st.experimental_set_query_params(logged_in="false")